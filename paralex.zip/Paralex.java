package paralex;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/*
 * Parallel Executor, author: k.ilyashenko, 13.01.2022
 * use:
 *		Paralex pro = new Paralex();
 *
 * 		for(...) pro.exec( new Work( pro, ... );		
 *
 *		pro.waitALL();
 *
 *	class Work implements Runnable{
 *		public Work( Paralex pro, Object q ... )
 *      {
 * 			var q = pro.getObj();  // if NO Free Proc. -> BLOCK & WAIT !!!
 *					...
 *       }
 *		public void run(){
 *				...
 *			pro.retObj( q );       // Free Proc. !!!
 *		}
 *	}
 */	
public class Paralex
{
	protected ExecutorService exec;
	protected int NP;
	protected ArrayBlockingQueue<Object> disp; 

	public Paralex() {
		exec = Executors.newWorkStealingPool();
		NP = java.lang.Runtime.getRuntime().availableProcessors();
		disp = new ArrayBlockingQueue<>( NP );
		for(int i=0;i<NP;i++) retObj( new Object());
	}
	
	public Object getObj(){
		Object bj = new Object();  
		try{ bj = disp.take();}
		catch( InterruptedException e ){ rupt();}
		return bj;
	}
	
	public void exec( Runnable work ){ exec.submit( work );}

	public void retObj( Object bj ){
		try{ disp.put( bj );}
		catch( InterruptedException e ){ rupt();} 
	}

	public void waitALL(){ while( disp.size() < NP ) waitms( 1 );}
	
	private static void waitms( int ms ){
		try { Thread.sleep( ms );}
		catch(Exception e){ rupt();}
	}
	private static void rupt(){ Thread.currentThread().interrupt();}
}
