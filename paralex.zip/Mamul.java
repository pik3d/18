package paralex;
import java.util.Arrays;
import java.util.stream.IntStream;

import pik.io;
import pik.mat;
/*
 * Matrix Multiply: Std., Strm, Parl
 * by k.ilyashenko, 13.01.2022   
 */
public class Mamul
{
	static void tt( String s ){ System.out.println( s );}
	long dt(){ long t=System.currentTimeMillis(), d=t-t0; t0=t; return d;} long t0=0;
	long dtn(){ long t=System.nanoTime(), d=t-t0n; t0n=t; return d;} long t0n=0;

	public static void main( String[] arg ){
		try{ new Mamul();} catch(Exception e){ e.printStackTrace();}
	}
	
	int NP = java.lang.Runtime.getRuntime().availableProcessors(),  N=100;

	Mamul() throws Exception
	{
tt("beg: "+NP+", N="+N+" - double"); dt();
		var A = randma( N, N ); // Nops = 2 * n^3 = 128 Gop
		var B = randma( N, N );

				Paralex pro = new Paralex(); // New EXEC.

		tt("gen: dt[ms] = "+dt()+"\n");

//		var C = mamul_std( A,B );
//		tt("Std. dt[ms] = "+dt()+", m="+C.length+", n="+C[0].length);
		
		double[][] F, E;
		F = mamul_parl( pro, A, B );
		tt("Parl dt[ms] = "+dt());

		E = mamul_strm( A, B );
		tt("Strm dt[ms] = "+dt());
tt("");
		F = mamul_parl( pro, A, B );
		tt("Parl dt[ms] = "+dt());

		E = mamul_strm( A, B );
		tt("Strm dt[ms] = "+dt());
tt("");
		F = mamul_parl( pro, A, B );
		tt("Parl dt[ms] = "+dt());

		E = mamul_strm( A, B );
		tt("Strm dt[ms] = "+dt());
tt("");
		F = mamul_parl( pro, A, B ); long nms=dt();    // F[99][99]=99; //dbg: 
		tt("Parl dt[ms] = "+nms);

		E = mamul_strm( A, B );
		tt("Strm dt[ms] = "+dt());
		
		tt("\ndelt = "+diff( E, F )+", dt[ms] = "+dt());

		double n =(double)N; long fps=Math.round(2.*n*n*n/nms)/1000000L;
		tt("\nComp.Power = "+fps+" Gflps");
tt("__________________________MULT.End.");

		var ac = randma( N, 1 ); // column * line
		var bl = randma( 1, N );
dt();
		var acbl = mamul_parl( pro, ac, bl );
		tt("Col * Lin:\nparl: ii="+acbl.length+", jj="+acbl[0].length+", dt[ms] = "+dt());

		var abst = mamul_std( ac, bl );
		tt("std.: ii="+abst.length+", jj="+abst[0].length+", dt[ms] = "+dt());
		
		var abs = mamul_strm( ac, bl );
		tt("strm: ii="+abs.length+", jj="+abs[0].length+", dt[ms] = "+dt());
dtn();
		acbl = mamul_parl( pro, bl, ac );
		tt("Lin * Col [Ns]:\nparl: ii="+acbl.length+", jj="+acbl[0].length+", dt[Ns] = "+dtn());

		abst = mamul_std( bl, ac );
		tt("std.: ii="+abst.length+", jj="+abst[0].length+", dt[Ns] = "+dtn());
		
		abs = mamul_strm( bl, ac );
		tt("strm: ii="+abs.length+", jj="+abs[0].length+", dt[Ns] = "+dtn());
tt("__________________________Line * Column End.");

		var b1 = new double[ N ]; int i=N; while(i-->0) b1[i]=Math.random();
		
		var x2 = syslin( A, b1 );
		tt("\nSTRM delt = "+diff( col2d(b1), mamul_strm( A, col2d(x2)) )+", dt[ms] = "+dt());
io.ttar("__Strm.x2", x2);

		var x1 = mat.syslin( A, b1 );
		tt("\nEJML delt = "+diff( col2d(b1), mamul_strm( A, col2d(x1)) )+", dt[ms] = "+dt());
io.ttar("Syslin.x", x1);

		double[][] T={{1,2,3,0,0}
					 ,{0,4,5,6,0}
					 ,{0,0,7,8,9}
					 ,{0,0,0,4,0}
					 ,{0,1,0,0,0}};	double[] bt={1,2,3,4,5};
		io.q();
		io.ttar("STRM", syslin( T, bt ));
		io.ttar("EJML", mat.syslin ( T, bt ));
io.q();		
		io.ttar( mamul_strm( T, invert( T )));
		dt();
		var Q = invert( A );
		tt("\nInverse( A ), dt[ms] = "+dt());

tt("-------------------------------------------------------------------- BAD:");		
		double[][] bad= {{ 1,       56,      3136,    1.756e+5 }
						,{ 1,       57,      3249,    1.852e+5 }
						,{ 0,       1,       112,     9408     }
						,{ 0,       1,       114,     9747     }};
		double[] 	xx=  { 320,     321,     0,       .4545    };
		
		io.ttar( mat.syslin( bad, xx ));
tt("------------------------------------------------------ ^ejml, vMy:");		
		io.ttar( syslin( bad, xx ));
		
	}
/*
 * SYSLIN, stream	
 */
	public static double[] syslin( double[][] a, double[] b )
	{
		int N =a.length;
		if( N!=a[0].length || N!=b.length ) throw new IllegalArgumentException();
		
		var A = new double[ N ][ N+1 ];
		IntStream.range( 0,N ).parallel().forEach( m->{
			System.arraycopy( a[m],0, A[m],0, N );
			A[m][N] = b[m];
		});
				var ref = seqElim( A );

		var x = new double[N];
		for(int i=0; i<N; i++) x[i] = A[ ref[ i ]][N];
		return x;
	}
/*
 * INVERT Matrix	
 */
	public static double[][] invert( double[][] a )
	{
		int N =a.length, NN=N+N;
		if( N!=a[0].length ) throw new IllegalArgumentException();
		
		var A = new double[ N ][ N+N ];
		IntStream.range( 0,N ).parallel().forEach( m->{
			System.arraycopy( a[m],0, A[m],0, N );
			Arrays.fill(      A[m], N, NN, 0.);
			A[m][N+m] = 1.;
		});
				var ref = seqElim( A );

		var x = new double[ N ][ N ];
		IntStream.range( 0,N ).parallel().forEach( m->
			System.arraycopy( A[ ref[m] ],N, x[m],0, N ));
		return x;
	}
/*
 * Gauss: Sequential Elimination	
 */
	public static int[] seqElim( double[][] A )
	{
		int N =A.length, NN=A[0].length, i,j,k=0,n;
		var ref = new int[N];
		var lin = new boolean[N]; Arrays.fill( lin, true );
		
		double q, xk;
		for(n=0; n<N; n++){
			xk=-1;
			for(i=0; i<N; i++)
				if( lin[i] && (q=Math.max( xk,Math.abs( A[i][n]))) >xk ){xk=q;k=i;}
			
			lin[k] = false;
			ref[n] = k;
			
			final int n_=n, n1=n+1, k_=k;
			for(j=n1; j<NN;j++) A[k][j] /= A[k][n]; 
			
			IntStream.range( 0,N ).parallel().forEach( m -> {
				if(m != k_) for(int t=n1; t<NN; t++) A[m][t] -= A[k_][t]*A[m][n_];
			});
		}
		return ref;
	}
/*
 * Matrix Multiply PARALLEL !!!	
 */
	public double[][] mamul_parl( Paralex pro, double[][] aa, double[][] bb ) throws Exception
	{
		a=aa; b=bb;
		int ja=a[0].length, jb=b[0].length, j;
		if( ja!=b.length ) throw new IllegalArgumentException();
		c = new double[ a.length ][ jb ];

		for(j=0; j<jb; j++)	pro.exec( new Mult( pro, j ));

		pro.waitALL();
		return c;
	}
	private double[][] a,b,c;

	class Mult implements Runnable {
		Paralex pr; double[] bj;
		int j, kk=a[0].length;

		Mult( Paralex pro, int jj ){
			j=jj;  pr=pro;
			Object q =pro.getObj();		 // if NO Free Proc. -> BLOCK & WAIT !!!
			if( !( q instanceof double[])
				|| ((double[])q).length < kk ) q = new double[ kk ];
			bj  =   (double[])q;
		}
		
		public void run() {
			int k, i;
			for(k=0; k<kk; k++) bj[k] = b[k][j];
			
			for(i=0; i<a.length; i++) {
				c[i][j]=0;
				for(k=0; k<kk; k++) c[i][j] += a[i][k]*bj[k]; 
			}
			pr.retObj( bj );
		}
	}
/*
 * Matrix Multiply STREAM !!!	
 */
	public static double[][] mamul_strm( double[][] a, double[][] b ) throws Exception
	{
		int ia =a.length, ja=a[0].length, jb=b[0].length;
		if( ja!=b.length ) throw new IllegalArgumentException();
		
		var c = new double[ia][jb];
		IntStream.range( 0, jb ).parallel().forEach( j ->
		{
			var bj = new double[ ja ];
			for(int k=0;k<ja;k++) bj[k] = b[k][j];
			
			IntStream.range( 0, ia ).parallel().forEach( i ->
			{
				c[i][j]=0;
				for(int k=0; k<ja; k++) c[i][j] += a[i][k]*bj[k]; 
			});
		});
		return c;
	}
/*
 * Matrix Multiply Standard	
 */
	public static double[][] mamul_std( double[][] a, double[][] b ) throws Exception
	{
		int ia=a.length, ja=a[0].length, jb=b[0].length,  i,j,k;
		if( ja!=b.length ) throw new IllegalArgumentException();
		
		var c = new double[ia][jb];
		for(j=0; j<jb; j++) {
			var bj = new double[ ja ];
			for(k=0;k<ja;k++) bj[k] = b[k][j];
			for(i=0;i<ia;i++) {
				c[i][j]=0;
				for(k=0;k<ja;k++) c[i][j] += a[i][k]*bj[k]; 
			}
		}
		return c;
	}
 /*
 * Matrix Multiply NO Optimize	
 *
	public static double[][] mamul_nop( double[][] a, double[][] b ) throws Exception
	{
		int ia=a.length, ja=a[0].length, jb=b[0].length,  i,j,k;
		if( ja!=b.length ) throw new IllegalArgumentException();
		
		var c = new double[ia][jb];
		for(i=0; i<ia; i++) {
			for(j=0; j<jb; j++) {
				c[i][j]=0;
				for(k=0;k<ja;k++) c[i][j] += a[i][k]*b[k][j]; 
			}
		}
		return c;
	}
 *
 * 	Matrix Delta = Max( Aij - Bij ) 
 */
	static double[][] lin2d( double[] a ){
		int ii=a.length;
		var aa=new double[1][ii]; System.arraycopy( a,0, aa[0],0, ii );
		return aa;
	}
	static double[][] col2d( double[] a ){
		int i=a.length;
		var aa=new double[i][1]; while(i-->0) aa[i][0]=a[i]; 
		return aa;
	}
	
	static double delta( double[] a, double[] b ){
		return diff( lin2d( a ), lin2d( b ));
	}

	static double diff( double[][] a, double[][] b ) {
		double d=-1;
		int ia=a.length, ja=a[0].length, i,j;
		if( ia!=b.length || ja!=b[0].length ) throw new IllegalArgumentException();

		for(i=0; i<ia; i++) {
			for(j=0; j<ja; j++) {
				var q = Math.abs( a[i][j] - b[i][j] );
				if( q > d ) d=q;
			}
		}
		return d;
	}
	static double[][] randma( int ii, int jj ){
		var d = new double[ii][jj];
		for(int i=0;i<ii;i++) for(int j=0;j<jj;j++) d[i][j] = Math.random();
		return d;
	}
}
