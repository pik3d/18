package paralex;
import java.util.stream.IntStream;
/*
 * Matrix Multiply: Std., Strm, Parl
 * by k.ilyashenko, 13.01.2022   
 */
public class MamulF
{
	void tt( String s ){ System.out.println( s );}
	long dt(){ long t=System.currentTimeMillis(), d=t-t0; t0=t; return d;} long t0=0;

	public static void main( String[] arg ){
		try{ new MamulF();} catch(Exception e){ e.printStackTrace();}
	}
	
	int NP = java.lang.Runtime.getRuntime().availableProcessors(),  N=2000;

	MamulF() throws Exception
	{
tt("beg: "+NP+", N="+N+" - float"); dt();
		var A = randma( N, N ); // Nops = 2 * n^3 = 128 Gop
		var B = randma( N, N );

				Paralex pro = new Paralex(); // New EXEC.

		tt("gen: dt[ms] = "+dt()+"\n");

//		var C = mamul_std( A,B );
//		tt("Std. dt[ms] = "+dt()+", m="+C.length+", n="+C[0].length);
		
		float[][] F, E;
		F = mamul_parl( pro, A, B );
		tt("Parl dt[ms] = "+dt());

		E = mamul_strm( A, B );
		tt("Strm dt[ms] = "+dt());
tt("");
		F = mamul_parl( pro, A, B );
		tt("Parl dt[ms] = "+dt());

		E = mamul_strm( A, B );
		tt("Strm dt[ms] = "+dt());
tt("");
		F = mamul_parl( pro, A, B );
		tt("Parl dt[ms] = "+dt());

		E = mamul_strm( A, B );
		tt("Strm dt[ms] = "+dt());
tt("");
		F = mamul_parl( pro, A, B ); long nms=dt();    // F[99][99]=99; //dbg: 
		tt("Parl dt[ms] = "+nms);

		E = mamul_strm( A, B );
		tt("Strm dt[ms] = "+dt());
		
		tt("\ndelt = "+delta( E, F )+", dt[ms] = "+dt());

		float n =(float)N; long fps=Math.round(2.*n*n*n/nms)/1000000L;
		tt("\nComp.Power = "+fps+" Gflps");
tt("__________________________End.");
	}
	
/*
 * Matrix Multiply PARALLEL !!!	
 */
	public float[][] mamul_parl( Paralex pro, float[][] aa, float[][] bb ) throws Exception
	{
		a=aa; b=bb;
		int ja=a[0].length, jb=b[0].length, j;
		if( ja!=b.length ) throw new IllegalArgumentException();
		c = new float[ a.length ][ jb ];

		for(j=0; j<jb; j++)	pro.exec( new Mult( pro, j ));

		pro.waitALL();
		return c;
	}
	private float[][] a,b,c;

	class Mult implements Runnable {
		Paralex pr; float[] bj;
		int j, kk=a[0].length;

		Mult( Paralex pro, int jj ){
			j=jj;  pr=pro;
			Object q =pro.getObj();		 // if NO Free Proc. -> BLOCK & WAIT !!!
			if( !( q instanceof float[])
				|| ((float[])q).length < kk ) q = new float[ kk ];
			bj  =   (float[])q;
		}
		
		public void run() {
			int k, i;
			for(k=0; k<kk; k++) bj[k] = b[k][j];
			
			for(i=0; i<a.length; i++) {
				c[i][j]=0;
				for(k=0; k<kk; k++) c[i][j] += a[i][k]*bj[k]; 
			}
			pr.retObj( bj );
		}
	}
/*
 * Matrix Multiply STREAM !!!	
 */
	public static float[][] mamul_strm( float[][] a, float[][] b ) throws Exception
	{
		int ia =a.length, ja=a[0].length, jb=b[0].length;
		if( ja!=b.length ) throw new IllegalArgumentException();
		
		var c = new float[ia][jb];
		IntStream.range( 0, jb ).parallel().forEach( j ->
		{
			var bj = new float[ ja ];
			for(int k=0;k<ja;k++) bj[k] = b[k][j];
			
			IntStream.range( 0, ia ).parallel().forEach( i ->
			{
				c[i][j]=0;
				IntStream.range( 0, ja ).forEach( k -> c[i][j] += a[i][k]*bj[k] ); 
			});
			
		});
		return c;
	}
/*
 * Matrix Multiply Standard	
 *
	public static float[][] mamul_std( float[][] a, float[][] b ) throws Exception
	{
		int ia=a.length, ja=a[0].length, jb=b[0].length,  i,j,k;
		if( ja!=b.length ) throw new IllegalArgumentException();
		
		var c = new float[ia][jb];
		for(j=0; j<jb; j++) {
			var bj = new float[ ja ];
			for(k=0;k<ja;k++) bj[k] = b[k][j];
			for(i=0;i<ia;i++) {
				c[i][j]=0;
				for(k=0;k<ja;k++) c[i][j] += a[i][k]*bj[k]; 
			}
		}
		return c;
	}
 *
 * Matrix Multiply NO Optimize	
 *
	public static float[][] mamul_nop( float[][] a, float[][] b ) throws Exception
	{
		int ia=a.length, ja=a[0].length, jb=b[0].length,  i,j,k;
		if( ja!=b.length ) throw new IllegalArgumentException();
		
		var c = new float[ia][jb];
		for(i=0; i<ia; i++) {
			for(j=0; j<jb; j++) {
				c[i][j]=0;
				for(k=0;k<ja;k++) c[i][j] += a[i][k]*b[k][j]; 
			}
		}
		return c;
	}
 *
 * 	Matrix Delta = Max( Aij - Bij ) 
 */
	static float delta( float[][] a, float[][] b ) {
		float d=-1;
		int ia=a.length, ja=a[0].length, i,j;
		if( ia!=b.length || ja!=b[0].length ) throw new IllegalArgumentException();

		for(i=0; i<ia; i++) {
			for(j=0; j<ja; j++) {
				var q = Math.abs( a[i][j] - b[i][j] );
				if( q > d ) d=q;
			}
		}
		return d;
	}
	static float[][] randma( int ii, int jj ){
		var d = new float[ii][jj];
		for(int i=0;i<ii;i++) for(int j=0;j<jj;j++) d[i][j] = (float)Math.random();
		return d;
	}
}
