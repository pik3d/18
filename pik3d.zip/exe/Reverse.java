package usr;
import java.util.ArrayList;
import pik.io;

public class Reverse extends io {
  public static void main( String[] a ) throws Exception {
    var ff = new ArrayList<float[][]>();

    io rr = new io(a[0]);
    float[][] v;
    while( (  v=rr.inBlock()) !=null ) ff.add( v );  //input  Kadr
    rr.close();

    int i=ff.size();
    while(--i >=0 ) ttBlock( ff.get( i ), 4 );       //out Kadr in Reverse
    clott();
  }
}
// > jj  Reverse.java  Stk > RevStk
// > jj  Reverse.java  Stk | s3d #
